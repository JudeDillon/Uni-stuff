package guitest;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class UI extends JFrame {

    private final Control controlPanel = new Control();
    SavingsAccount savingTimer = new SavingsAccount(0, this, controlPanel);
    CurrentAccount currentTimer = new CurrentAccount(0, this, controlPanel);

    private final int width = 1700;
    private final int height = 900;
    private final Color malibu = new Color(107, 185, 240);

    public UI() {
        initFrame();
        setVisible(true);
    }

    private void initFrame() {
        this.addControlPanel();
        this.setLayout();
        this.addListeners();
    }

    private void addListeners() {
        //This is for starting the timer 
        controlPanel.createAccBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int initBal = 0;
                try {
                    initBal = Integer.parseInt(controlPanel.intiBalTxt.getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please Input a number for the intial balance in digits", "Error", JOptionPane.WARNING_MESSAGE);
                }

                if (controlPanel.accTypeBox.getSelectedIndex() == 1) {
                    if (initBal > 0) {
                        controlPanel.createAccBtn.setEnabled(false);
                        currentTimer.setFirstAmount(Integer.parseInt(controlPanel.intiBalTxt.getText()));
                        currentTimer.timer();
                    } else {
                        JOptionPane.showMessageDialog(null, "Current account must have an initial value of over 0", "Error", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    if (initBal > 99) {
                        controlPanel.createAccBtn.setEnabled(false);
                        savingTimer.setFirstAmount(Integer.parseInt(controlPanel.intiBalTxt.getText()));
                        savingTimer.timer();
                    } else {
                        JOptionPane.showMessageDialog(null, "Savings account must have an initial value of 100 or above", "Error", JOptionPane.WARNING_MESSAGE);
                    }
                }
            }
        });

        //This Focus listener causes the text in the box to disappear when it is clicked on
        controlPanel.intiBalTxt.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent fe) {
                controlPanel.intiBalTxt.setText("");
            }

            @Override
            public void focusLost(FocusEvent e) {
                //Abstract method that does nothing but must be included
            }
        });

        //This is the listener to stop the timer 
        controlPanel.stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (controlPanel.accTypeBox.getSelectedIndex() == 1) {
                    currentTimer.stopTimer();
                } else {
                    savingTimer.stopTimer();
                }
                addDrawingPanels();
            }
        });

        //The following code allows a dialogue box to pop up ensuring the user meant to close
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                JFrame frame = (JFrame) e.getSource();

                int result = JOptionPane.showConfirmDialog(
                        frame,
                        "Are you sure you want to exit the application?",
                        "Exit Application",
                        JOptionPane.YES_NO_OPTION);

                if (result == JOptionPane.YES_OPTION) {
                    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                }
            }
        });
    }

    private void addControlPanel() {
        this.getContentPane().add(controlPanel);
    }

    private void addDrawingPanels() {
        //adds the graph to pane
        Drawing drawingPanel;
        if (controlPanel.accTypeBox.getSelectedIndex() == 1) {
            drawingPanel = new Drawing(currentTimer.getTransList(), currentTimer.getBalanceList());
        } else {
            drawingPanel = new Drawing(savingTimer.getTransList(), savingTimer.getBalanceList());
        }
        this.getContentPane().add(drawingPanel);

        //adds the graph results to pane
        ResultPanel results;
        if (controlPanel.accTypeBox.getSelectedIndex() == 1) {
            results = new ResultPanel(currentTimer);
        } else {
            results = new ResultPanel(savingTimer);
        }
        this.getContentPane().add(results);

        this.setLayoutWithGraph(drawingPanel, results);
        results.getTextOnScreen(controlPanel.accTypeBox.getSelectedIndex());

        //these methods cause the pane to become visible
        this.pack();
        this.revalidate();
    }

    public void playButton(JButton graphButton) {
        //adds the Timer
        if (controlPanel.accTypeBox.getSelectedIndex() == 1) {
            currentTimer.timer();
        } else {
            savingTimer.timer();
        }
    }

    //this is the layout before any other panels are added
    private void setLayout() {
        setMinimumSize(new java.awt.Dimension(width, height));
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);

        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(controlPanel)
                        )
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(controlPanel)
        );
    }

    //This is to be the layout after graph added must have original layout and size or graph will not work properly
    private void setLayoutWithGraph(JPanel theNewGraphPanel, JPanel theNewResultsPanel) {
        theNewResultsPanel.setBackground(malibu);
        theNewGraphPanel.setBackground(malibu);
        setMinimumSize(new java.awt.Dimension(width, height));
        GroupLayout layoutWithGraph = new GroupLayout(getContentPane());
        getContentPane().setLayout(layoutWithGraph);

        layoutWithGraph.setHorizontalGroup(
                layoutWithGraph.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layoutWithGraph.createSequentialGroup()
                                .addComponent(controlPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                .addComponent(theNewGraphPanel, 700, 700, 700)
                                // .addComponent(rootPane)
                                .addComponent(theNewResultsPanel, 500, 500, 500)
                        //.addComponent(rootPane)    
                        )
        );
        layoutWithGraph.setVerticalGroup(
                layoutWithGraph.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(controlPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(theNewGraphPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(theNewResultsPanel, 300, 300, 300)
        );
    }
}
