/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guitest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author User
 */
public class SavingsAccount extends AccountInterface
{
    //constructor
    public SavingsAccount(int startingAmount) 
    {
        super(startingAmount);
    
        firstAmount = startingAmount;
    }
    
    private int firstAmount;
    private int firstAmountAdded = 0;
    private int currentTrans = 0;
    private Integer ballanceInAccount = 0;
    private int numOfWithdrawals = 0;
    private int monthCounter = 0;
    
    //This will be the array that will keep track of the transactions each month 
     ArrayList<Integer> transactionsList = new ArrayList<Integer>();
    
    //This will be the array tracking the balances at each month
    ArrayList<Integer> arrayOfBalances = new ArrayList<Integer>();
    
    //A sorted copy of the arrayOfBalances to allow getting the max values by sorting it
    ArrayList<Integer> sortedArrayOfBalances = new ArrayList<Integer>();
    
    @Override
    public void timer() 
    {
        schedule(new TimerTask() 
        {
            @Override
            public void run() 
            {
                if(monthCounter > 11)
                {
                    numOfWithdrawals = 0;
                    monthCounter = 0;
                }
                
                if (firstAmountAdded == 0)
                {
                    transactionsList.add(firstAmount);
                    ballanceInAccount = ballanceInAccount + getCurrentValue();
                    Double interestBallanceInAccount = ballanceInAccount.doubleValue() * 1.03;
                    ballanceInAccount = interestBallanceInAccount.intValue();
                    arrayOfBalances.add(ballanceInAccount);
                    firstAmountAdded++;
                }
                else
                {
                    currentTrans=getValue(isDeposit(), randomValue());
                    ballanceInAccount = ballanceInAccount + getCurrentValue();                    
                    Double interestBallanceInAccount = ballanceInAccount.doubleValue() * 1.03;
                    ballanceInAccount = interestBallanceInAccount.intValue();
                    arrayOfBalances.add(ballanceInAccount);
                    transactionsList.add(currentTrans);
                }
                monthCounter++;
            }
        }, 0, 5000); 
    }
    
    //TODO this method should be in super class as is used in savings account
        private void balances()
    {
        for (int i=0; i<getTransList().size(); i++)
        {
            arrayOfBalances.add(ballanceInAccount);
        }
    }
        
    //TODO turn this method to spit out a string that goes to the text pane
    //This method gets and sorts the balancesarray and displaying the values
    public void getResultText2()
    {
        //Move this method to the result panel have a parameter for this method be the reference for the current account class
    	sortedArrayOfBalances = getBalanceList();
        
        System.out.println("These are the balances chronologically" + getBalanceList());
        //getMaxAndMinBalances2();
        System.out.println("This is the final balance "+ getBalanceList().get(getBalanceList().size()-1));
       
        Collections.sort(sortedArrayOfBalances);      
        System.out.println("This a list of the sorted balances" + sortedArrayOfBalances);
    }
    
    //TODO this method should be in super class as is used in savings account
    //this method finds the month that a value was obtained
    protected Integer findMonthOfBalance(Integer goalValue)
    {
        int i=0;
        while (true)
        {
            
            if (arrayOfBalances.get(i) == goalValue)
            {
                break;
            }
            i++;
        }
        return i;
    }

    //TODO this method should be in super class as is used in savings account
    //This method gets the min and Max balance and their dates 
    protected String getMaxAndMinBalances2(ArrayList<Integer> array)
    {
        //System.out.println("This is the max value, " + Collections.max(sortedArrayOfBalances)+ " Which was during month " + findMonthOfBalance(Collections.max(sortedArrayOfBalances)));
        //System.out.println("This is the min value, " + Collections.min(sortedArrayOfBalances)+ " Which was during month " + findMonthOfBalance(Collections.min(sortedArrayOfBalances)));
        
        String s = "The max balance was " + Collections.max(array)+ "  during month " + findMonthOfBalance(Collections.max(array));
        s += "\nThe min balance was " + Collections.min(array)+ " during month " + findMonthOfBalance(Collections.min(array));
        
        return s;
    }
    
    public ArrayList getTransList()
    {
        return transactionsList;
    }
    
    public void setFirstAmount(int amount)
    {
        firstAmount = amount;
    }
    
    public int getCurrentValue()
    {
        System.out.println(currentTrans);
        return currentTrans;
    }
    
    public ArrayList getBalanceList()
    {
        return arrayOfBalances;
    }
    
    public Timer getTimer()
    {
        return this;
    }
    
    
    //this is called to stop the timer and create the balancearray and show the results 
    public void stopTimer()
    {
        cancel();
        purge();
        balances();
    }
    
    public boolean isDeposit() 
    {
        Random r = new Random();
        boolean i = r.nextBoolean();
        return i;
    }
    
    public int randomValue()
    {
        Random r = new Random();
        int value = 100 + r.nextInt(2000);
        return value;
    }
    
    public int getValue(boolean isDeposit, int value)
    {
        if(isDeposit)
        {
            return value;
        }
        else
        {
            if(numOfWithdrawals > 1)
            {
                System.out.println("Error cannot make more than 2 withdrawals in a year");
                return 0;
            }
            else if(ballanceInAccount - value < 100)
            {
                System.out.println("Error cannot make a transaction that would cause a balance of less than £100");
                return 0;
            }
            else{
                numOfWithdrawals++;
                return (-1 * value);
            }
        }
    }
}
