/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guitest;

import java.awt.Font;
import java.util.ArrayList;
import java.util.Collections;

import static java.awt.SystemColor.text;
import javax.swing.*;

/**
 *
 * @author Ryan
 */

public class ResultPanel extends JPanel {
	CurrentAccount ca;
	JTextArea textArea;
	ArrayList<Integer> sortedArrayOfBalances = new ArrayList<Integer>();

	ResultPanel(CurrentAccount ca) {
		this.ca = ca;
		setLayout();
	}

	private String textOnScreen;

	public String getTextOnScreen() {

		String output;
		sortedArrayOfBalances = ca.getBalanceList();

		output = "These are the balances chronologically" + ca.getBalanceList();
		output += "\n" + ca.getMaxAndMinBalances2(sortedArrayOfBalances);

		output += "This is the final balance " + ca.getBalanceList().get(ca.getBalanceList().size() - 1);

		Collections.sort(sortedArrayOfBalances);
		System.out.println("This a list of the sorted balances" + sortedArrayOfBalances);

		System.out.println(output);
		textArea.setText(output);
		return output;
	}

	private void setLayout() {

		JScrollPane jScrollPane1 = new javax.swing.JScrollPane();
		textArea = new javax.swing.JTextArea();
		textArea.setFont(new Font("Serif", Font.ITALIC, 17));
		textArea.setEditable(false);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);

		jScrollPane1.setViewportView(textArea);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
		this.setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				layout.createSequentialGroup().addContainerGap()
						.addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
						.addContainerGap()));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				layout.createSequentialGroup().addContainerGap()
						.addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
						.addContainerGap()));
	}
}