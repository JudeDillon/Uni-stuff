/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guitest;

import java.awt.Font;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.*;

/**
 *
 * @author Ryan
 */
public class ResultPanel extends JPanel
{

    CurrentAccount current;
    SavingsAccount saving;

    JTextArea textArea;
    ArrayList<Integer> sortedArrayOfBalances = new ArrayList();

    ResultPanel(CurrentAccount ca)
    {
        current = ca;
        setLayout();
    }

    ResultPanel(SavingsAccount sa)
    {
        saving = sa;
        setLayout();
    }

    //this gets the required info from the current account and displays it on the results panel
    public String getTextOnScreen(int typeOfAccount)
    {

        String output;
        if (/*controlPanel.accTypeBox.getSelectedIndex()*/typeOfAccount == 1)
        {
            sortedArrayOfBalances = current.getBalanceList();
            output = "These are the balances chronologically" + current.getBalanceList();
            output += "\n" + current.getMaxAndMinBalances2(sortedArrayOfBalances);

            output += "\nThis is the final balance " + current.getBalanceList().get(current.getBalanceList().size() - 1);
        } else
        {
            sortedArrayOfBalances = saving.getBalanceList();
            output = "These are the balances chronologically" + saving.getBalanceList();
            output += "\n" + saving.getMaxAndMinBalances2(sortedArrayOfBalances);

            output += "\nThis is the final balance " + saving.getBalanceList().get(saving.getBalanceList().size() - 1);
        }

        Collections.sort(sortedArrayOfBalances);
        System.out.println("This a list of the sorted balances" + sortedArrayOfBalances);

        textArea.setText(output);
        return output;
    }

    private void setLayout()
    {

        JScrollPane jScrollPane1 = new javax.swing.JScrollPane();
        textArea = new javax.swing.JTextArea();
        textArea.setFont(new Font("Serif", Font.BOLD, 17));
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        jScrollPane1.setViewportView(textArea);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
                javax.swing.GroupLayout.Alignment.TRAILING,
                layout.createSequentialGroup().addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                        .addContainerGap()));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
                javax.swing.GroupLayout.Alignment.TRAILING,
                layout.createSequentialGroup().addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                        .addContainerGap()));
    }
}
