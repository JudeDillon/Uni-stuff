/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guitest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author b00741734
 */
public class CurrentAccount extends AccountInterface
{

    //constructor
    public CurrentAccount(int startingAmount,UI uiIn, Control controlIn)
    {
        super(startingAmount);

        control = controlIn;
        ui = uiIn;
        firstAmount = startingAmount;
    }
    
    private Control control;
    private UI ui;
    private int firstAmount;
    private int firstAmountAdded = 0;
    private int currentTrans = 0;
    private Integer ballanceInAccount = 0;
    private int monthCounter = 0;
    private int yearCounter = 0;
    private String exception; 

    //This will be the array that will keep track of the transactions each month 
    ArrayList<Integer> transactionsList = new ArrayList();

    //This will be the array tracking the balances at each month
    ArrayList<Integer> arrayOfBalances = new ArrayList();

    //A sorted copy of the arrayOfBalances to allow getting the max values by sorting it
    ArrayList<Integer> sortedArrayOfBalances = new ArrayList();
    
    //A list of all exceptions and the month they occured
    ArrayList<String> exceptionArray = new ArrayList();

    @Override
    public void timer()
    {
        schedule(new TimerTask()
        {
            @Override
            public void run()
            {
                if (monthCounter > 11)
                {
                    monthCounter = 0;
                    yearCounter++;
                }
                if (firstAmountAdded == 0)
                {
                    transactionsList.add(firstAmount);
                    currentTrans = firstAmount;
                    ballanceInAccount = ballanceInAccount + getCurrentValue();
                    arrayOfBalances.add(ballanceInAccount);
                    firstAmountAdded++;
                    control.setCurrentBalance(getCurrentValue());
                    control.setCurrentTrans(getCurrentValue());
                    ui.revalidate();
                    ui.pack();
                    
                } else
                {
                    currentTrans = getValue(isDeposit(), randomValue());
                    control.setCurrentTrans(getCurrentValue());
                    ui.revalidate();
                    ui.pack();
                    ballanceInAccount = ballanceInAccount + getCurrentValue();
                    transactionsList.add(currentTrans);
                    arrayOfBalances.add(ballanceInAccount);
                }
                monthCounter++;
            }
        }, 0, 5000);
    }

    //TODO this method should be in super class as is used in savings account
    //this method finds the month that a value was obtained
    protected Integer findMonthOfBalance(Integer goalValue)
    {
        int i = 0;
        while (true)
        {

            if (arrayOfBalances.get(i) == goalValue)
            {
                break;
            }
            i++;
        }
        return i;
    }

    //This method gets the min and Max balance and their dates 
    protected String getMaxAndMinBalances2(ArrayList<Integer> array)
    {
        String s = "The max balance was " + Collections.max(array) + "  during month " + findMonthOfBalance(Collections.max(array));
        s += "\nThe min balance was " + Collections.min(array) + " during month " + findMonthOfBalance(Collections.min(array));

        return s;
    }

    public ArrayList getTransList()
    {
        return transactionsList;
    }

    public void setFirstAmount(int amount)
    {
        firstAmount = amount;
    }

    public int getCurrentValue()
    {
        //System.out.println(currentTrans);
        return currentTrans;
    }

    public ArrayList getBalanceList()
    {
        return arrayOfBalances;
    }

    public Timer getTimer()
    {
        return this;
    }

    //this is called to stop the timer and create the balancearray and show the results 
    public void stopTimer()
    {
        cancel();
        purge();
    }

    public boolean isDeposit()
    {
        Random r = new Random();
        boolean i = r.nextBoolean();
        return i;
    }

    public int randomValue()
    {
        Random r = new Random();
        int value = 100 + r.nextInt(2000);
        return value;
    }
    
    public ArrayList getException()
    {
        return exceptionArray;
    }

    public int getValue(boolean isDeposit, int value)
    {
        if (isDeposit)
        {
            if (value > 500)
            {
                value = value + 10;
            }
            
            //This code allows the Jlabel to update the current balance as the transaction occurs
            control.setCurrentBalance(control.getCurrentBalance()+value);
            //control.setCurrentTrans(getCurrentValue());
            ui.revalidate();
            ui.pack();
            
            return value;
            
        } else
        {
            if (ballanceInAccount - value < -1000)
            {
                System.out.println("Error cannot make a transaction that would cause an overdraft of over £1000      Year " + yearCounter + " Month " + monthCounter);
                exceptionArray.add("Error cannot make a transaction that would cause an overdraft of over £1000      Year " + yearCounter + " Month " + monthCounter);
                return 0;
            } else
            {
                return (-1 * value);
            }
        }
    }
}
